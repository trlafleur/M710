'
' Instantiate this class for each serial port to be accessed. 
'
' To set the basic port parameters call the 'Settings' method with a string argument
' of the form "9600,N,8,1" - <Baud Rate>,<Parity>,<Byte Size>,<Stop Bits>. This can only
' be done when the port is closed. 
'
' Hardware flow control can be turned on by setting the 'FlowControl' method to True
' and turned off by setting it to False. This must be done when the port is closed. This
' class does not support X-On/X-Off flow control.
'
' To open the port set the method 'Open()' with the port number for an argument. The
' port number may either be an integer, Example: Open(1), or a string, Example: 
' Open("COM1").
'
' To send data call either the SendString() or SendBytes() method with the data to be 
' either as a string or a byte array. Strings may not include Chr(0).
'
' To receive data call the ReceiveString() or ReceiveBytes() method and it will return
' ALL buffered receive data. Use the receive string method only for ASCII strings. If
' no data is available then these methods will return either and empty string or a null
' byte array (Ubound(bytes) will equal -1).
'
' The DTR method will turn the DTR line on or off with an argument of True or
' False. It always defaults to True each time the port it opened.
'
' The following methods can return the status of the serial port control
' lines: CTS, DSR, RING, and RLSD (carrier detect line).
'

Option Compare Text
Option Strict On

Imports System.Runtime.InteropServices
Imports System.Threading
Imports System.Text

Public Class SerialPort
#Region "Structures"
   ' This is the DCB structure used by the calls to the Windows API.
   <StructLayout(LayoutKind.Sequential, Pack:=1)> Private Structure DCB
      Public DCBlength As Integer
      Public BaudRate As Integer
      Public Flags As Integer
      Public wReserved As Int16
      Public XonLim As Int16
      Public XoffLim As Int16
      Public ByteSize As Byte
      Public Parity As Byte
      Public StopBits As Byte
      Public XonChar As Byte
      Public XoffChar As Byte
      Public ErrorChar As Byte
      Public EofChar As Byte
      Public EvtChar As Byte
      Public wReserved2 As Int16
   End Structure

   ' This is the CommTimeOuts structure used by the calls to the Windows API.
   <StructLayout(LayoutKind.Sequential, Pack:=1)> Private Structure COMMTIMEOUTS
      Public ReadIntervalTimeout As Integer
      Public ReadTotalTimeoutMultiplier As Integer
      Public ReadTotalTimeoutConstant As Integer
      Public WriteTotalTimeoutMultiplier As Integer
      Public WriteTotalTimeoutConstant As Integer
   End Structure

   ' This is the CommConfig structure used by the calls to the Windows API.
   <StructLayout(LayoutKind.Sequential, Pack:=1)> Private Structure COMMCONFIG
      Public dwSize As Integer
      Public wVersion As Int16
      Public wReserved As Int16
      Public dcbx As DCB
      Public dwProviderSubType As Integer
      Public dwProviderOffset As Integer
      Public dwProviderSize As Integer
      Public wcProviderData As Byte
   End Structure
#End Region

#Region "Class Constants"
   Private Const MAXDWORD As Integer = &HFFFFFFFF
   Private Const GENERIC_READ As Integer = &H80000000
   Private Const GENERIC_WRITE As Integer = &H40000000
   Private Const OPEN_EXISTING As Integer = 3

   ' GetCommModemStatus flags
   Private Const MS_CTS_ON As Integer = &H10&
   Private Const MS_DSR_ON As Integer = &H20&
   Private Const MS_RING_ON As Integer = &H40&
   Private Const MS_RLSD_ON As Integer = &H80&
#End Region

#Region "Win32API"
   ' The following functions are the required Win32 functions needed to 
   '   make communication with the Comm Port possible.

   <DllImport("kernel32.dll")> Private Shared Function BuildCommDCB( _
     ByVal lpDef As String, ByRef lpDCB As DCB) As Integer
   End Function

   <DllImport("kernel32.dll")> Private Shared Function SetCommTimeouts( _
         ByVal hFile As Integer, ByRef lpCommTimeouts As COMMTIMEOUTS) As Integer
   End Function

   <DllImport("kernel32.dll")> Private Shared Function CreateFile( _
    <MarshalAs(UnmanagedType.LPStr)> ByVal lpFileName As String, _
    ByVal dwDesiredAccess As Integer, ByVal dwShareMode As Integer, _
    ByVal lpSecurityAttributes As Integer, _
    ByVal dwCreationDisposition As Integer, _
    ByVal dwFlagsAndAttributes As Integer, _
    ByVal hTemplateFile As Integer) As Integer
   End Function

   <DllImport("kernel32.dll")> Private Shared Function CloseHandle( _
       ByVal hObject As Integer) As Integer
   End Function

   <DllImport("kernel32.dll")> Private Shared Function CreateEvent( _
       ByVal lpEventAttributes As Integer, ByVal bManualReset As Integer, _
       ByVal bInitialState As Integer, _
       <MarshalAs(UnmanagedType.LPStr)> ByVal lpName As String) As Integer
   End Function

   <DllImport("kernel32.dll")> Private Shared Function SetCommState( _
       ByVal hCommDev As Integer, ByRef lpDCB As DCB) As Integer
   End Function

   <DllImport("kernel32.dll")> Private Shared Function SetupComm( _
       ByVal hFile As Integer, ByVal dwInQueue As Integer, _
       ByVal dwOutQueue As Integer) As Integer
   End Function

   <DllImport("kernel32.dll")> Public Shared Function GetCommModemStatus( _
       ByVal hFile As Integer, ByRef lpModemStatus As Integer) As Boolean
   End Function

   <DllImport("kernel32.dll")> Private Shared Function WaitForSingleObject( _
       ByVal hHandle As Integer, ByVal dwMilliseconds As Integer) As Integer
   End Function

   <DllImport("kernel32.dll")> Private Shared Function WriteFile( _
       ByVal hFile As Integer, ByVal Buffer As Byte(), _
       ByVal nNumberOfBytesToWrite As Integer, _
       ByRef lpNumberOfBytesWritten As Integer, _
       ByRef lpOverlapped As Object) As Integer
   End Function

   <DllImport("kernel32.dll")> Private Shared Function ReadFile( _
       ByVal hFile As Integer, ByVal Buffer As Byte(), _
       ByVal nNumberOfBytesToRead As Integer, _
       ByRef lpNumberOfBytesRead As Integer, _
       ByRef lpOverlapped As Object) As Integer
   End Function
#End Region

#Region "Class Variables"
   Private tDCB As New DCB ' Serial port device control block structure
   Private tTimeouts As New COMMTIMEOUTS ' Serial port timeout structure
   Private hPort As Integer ' Serial port handle from CreateFile()
   Private bOpen As Boolean ' True when the port is open 
   Private nOutputBufferSize As Integer ' Holds the port's output buffer size
   Private nInputBufferSize As Integer  ' Holds the port's input buffer size

   ' Holds input data while waiting to be read or written...
   Private queToPort As New Queue   ' Queue of bytes waiting to be sent to the port
   Private queFromPort As New Queue ' Queue of bytes received from the port 

   ' The port read/write thread...
   Private thrReadWrite As Thread
#End Region

#Region "Methods"
   ' Constructor for this class...
   Public Sub New()
      ' Set default values for the DCB...
      BuildCommDCB("baud=1200 parity=N data=8 stop=1", tDCB)

      ' Initialize the tTimeouts...
      tTimeouts.ReadIntervalTimeout = MAXDWORD
      tTimeouts.ReadTotalTimeoutMultiplier = 0
      tTimeouts.ReadTotalTimeoutConstant = 0
      tTimeouts.WriteTotalTimeoutMultiplier = 0
      tTimeouts.WriteTotalTimeoutConstant = 0

      ' Initialize Buffer sizes (MSComm defaults)
      nInputBufferSize = 4096
      nOutputBufferSize = 4096
   End Sub

   ' Returns True if the serial port is open. Test after
   ' any call to Open()...
   Public Function IsOpen() As Boolean
      Return bOpen
   End Function

   ' Opens the serial port with 1, 2, 3, etc...
   Public Sub Open(ByVal nPort As Integer)
      Open("COM" & CStr(nPort))
   End Sub

   ' Opens the serial port with "COM1", "COM2", "COM3", etc...
   Public Sub Open(ByVal sPort As String)
      ' Close an existing port when reopening...
      bOpen = False
      If hPort <> 0 Then Close()

      ' Attempt to open the indicated serial port...
      hPort = CreateFile(sPort, GENERIC_READ Or GENERIC_WRITE, 0, 0, OPEN_EXISTING, 0, 0)
      If hPort = -1 Then Exit Sub
      SetupComm(hPort, nInputBufferSize, nOutputBufferSize)
      SetCommTimeouts(hPort, tTimeouts)
      ' This needs to be executed twice for some USB serial ports to work...
      SetCommState(hPort, tDCB)
      SetCommState(hPort, tDCB)

      bOpen = True
      thrReadWrite = New Thread(AddressOf ReadWritePort)
      thrReadWrite.Name = "PortReadWrite"
      thrReadWrite.Start()
   End Sub

   ' Closes the serial port...
   Public Sub Close()
      Dim nFlags As Integer
      bOpen = False
      Try
         thrReadWrite.Abort()
      Catch
         ' Do nothing - may have already stopped
      End Try
      thrReadWrite = Nothing
      queToPort.Clear()
      queFromPort.Clear()
      If hPort <> 0 Then
         nFlags = tDCB.Flags
         tDCB.Flags = (tDCB.Flags And &HCF)
         If hPort <> 0 Then
            ' This needs to be executed twice for some USB serial ports to work...
            SetCommState(hPort, tDCB)
            SetCommState(hPort, tDCB)
         End If
         tDCB.Flags = nFlags
         CloseHandle(hPort)
         hPort = 0
      End If
   End Sub

   ' sSettings should be in this format: 9600,N,8,1
   Public Sub Settings(ByVal sSettings As String)
      Dim sTokens() As String
      Dim nParity As Integer
      Dim nStop As Integer

      sTokens = Split(sSettings, ",")
      If UBound(sTokens) = 3 Then
         For nIndex As Integer = 0 To 3
            sTokens(nIndex) = Trim(sTokens(nIndex))
         Next nIndex
         Dim nBaudRate As Integer = CInt(sTokens(0))
         Select Case nBaudRate
            Case 110, 300, 600, 1200, 2400, 4800, 9600, 14400, 19200, 38400, 56000, 57600, 115200, 128000, 256000
               tDCB.BaudRate = nBaudRate
            Case Else
               MsgBox("ERROR: Unsupported baud rate...", MsgBoxStyle.Critical)
         End Select
         Select Case sTokens(1)
            Case "N" : nParity = 0
            Case "O" : nParity = 1
            Case "E" : nParity = 2
            Case "M" : nParity = 3
            Case "S" : nParity = 4
            Case Else : nParity = 0
         End Select
         tDCB.Parity = (CByte(nParity))
         tDCB.ByteSize = (CByte(sTokens(2)))
         Select Case sTokens(3)
            Case "1" : nStop = 0
            Case "1.5" : nStop = 1
            Case "2" : nStop = 2
         End Select
         tDCB.StopBits = (CByte(nStop))
      End If
   End Sub

   ' Input buffer defalts to 4096 bytes...
   Public Sub InputBufferSize(ByVal lSize As Integer)
      nInputBufferSize = lSize
   End Sub

   ' Output buffer defalts to 4096 bytes...
   Public Sub OutBufferSize(ByVal lSize As Integer)
      nOutputBufferSize = lSize
   End Sub

   ' Returns the number of bytes waiting to be read...
   Public Function InputQueueLength() As Integer
      Return queFromPort.Count
   End Function

   ' Returns the number of bytes waiting to be sent...
   Public Function OutputQueueLength() As Integer
      Return queToPort.Count
   End Function

   ' Enqueues an ASCII string to be sent (must not include
   ' a Chr(0)...
   Public Sub SendString(ByVal sText As String)
      If bOpen Then
         For nIndex As Integer = 0 To sText.Length - 1
            queToPort.Enqueue(CByte(Asc(sText.Chars(nIndex))))
         Next nIndex
      End If
   End Sub

   ' Returns the contents of the input queue...
   Public Function ReceiveString() As String
      If bOpen Then
         Dim sb As New StringBuilder
         While queFromPort.Count > 0
            Dim bin As Byte = CByte(queFromPort.Dequeue)
            If bin <> 0 Then sb.AppendFormat(Chr(bin))
         End While
         Return sb.ToString
      Else
         Return ""
      End If
   End Function

   ' Enqueues a binary byte array to be sent...
   Public Sub SendBytes(ByVal binData() As Byte)
      If bOpen Then
         For Each bin As Byte In binData
            queToPort.Enqueue(bin)
         Next
      End If
   End Sub

   ' Returns the contents of the input queue as a binary 
   ' byte array...
   Public Function ReceiveBytes() As Byte()
      If bOpen Then
         Dim bin(queFromPort.Count - 1) As Byte
         For nIndex As Integer = 0 To UBound(bin)
            bin(nIndex) = CByte(queFromPort.Dequeue)
         Next
         Return bin
      Else
         Dim bin(-1) As Byte
         Return bin
      End If
   End Function

   ' Hardware flow control can be turned on by setting the 
   ' 'FlowControl' property to True and turned off by setting 
   ' it to False. This must be done when the port is closed.
   ' X-On/X-Off flow control is not supported in this class...
   Public Sub FlowControl(ByVal bOn As Boolean)
      Dim nFlags As Integer

      nFlags = tDCB.Flags
      nFlags = nFlags And &HFFB
      If Not bOn Then
         nFlags = nFlags Or &H1011
      Else
         nFlags = nFlags Or &H2015
      End If
      tDCB.Flags = nFlags
   End Sub

   ' Turns on or off the DTR line from the port. Default is ON...
   Public Sub DTR(ByVal bOn As Boolean)
      Dim nFlags As Integer

      nFlags = tDCB.Flags
      If bOn Then
         nFlags = nFlags Or &H10
      Else
         nFlags = nFlags And &HFFCF
      End If
      tDCB.Flags = nFlags
      If bOpen Then
         ' This needs to be executed twice for some USB serial ports to work...
         SetCommState(hPort, tDCB)
         SetCommState(hPort, tDCB)
      End If
   End Sub

   ' These functions return the current serial port control 
   ' line status...
   Public Function CTS() As Boolean
      Dim lModemStatus As Integer

      If bOpen Then
         GetCommModemStatus(hPort, lModemStatus)
         Return (lModemStatus And MS_CTS_ON) <> 0
      End If
   End Function
   Public Function DSR() As Boolean
      Dim lModemStatus As Integer

      If bOpen Then
         GetCommModemStatus(hPort, lModemStatus)
         Return (lModemStatus And MS_DSR_ON) <> 0
      End If
   End Function
   Public Function RING() As Boolean
      Dim lModemStatus As Integer

      If bOpen Then
         GetCommModemStatus(hPort, lModemStatus)
         Return (lModemStatus And MS_RING_ON) <> 0
      End If
   End Function
   Public Function RLSD() As Boolean
      Dim lModemStatus As Integer

      If bOpen Then
         GetCommModemStatus(hPort, lModemStatus)
         Return (lModemStatus And MS_RLSD_ON) <> 0
      End If
   End Function

   ' This runs in its own thread...
   Private Sub ReadWritePort()
      Dim nResult As Integer
      Dim nDataCount As Integer
      Dim bin(0) As Byte
      Dim bActive As Boolean

      Do
         bActive = False
         If bOpen Then
            If queToPort.Count > 0 Then
               bActive = True
               bin(0) = CByte(queToPort.Dequeue)
               nDataCount = 0
               nResult = WriteFile(hPort, bin, 1, nDataCount, Nothing)
            End If
            nDataCount = 0
            Try
               nResult = ReadFile(hPort, bin, 1, nDataCount, Nothing)
            Catch
               bOpen = False
               Exit Sub
            End Try
            If nDataCount <> 0 Then
               bActive = True
               queFromPort.Enqueue(bin(0))
            End If
            If Not bActive Then
               thrReadWrite.Sleep(300)
            End If
         Else
            Exit Sub
         End If
      Loop
   End Sub
#End Region
End Class

